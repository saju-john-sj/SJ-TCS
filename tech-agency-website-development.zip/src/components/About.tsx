import { ArrowRight, CheckCircle2 } from "lucide-react";
import { scrollToTarget } from "../lib/scroll";
import { Counter, Eyebrow, Gradient, Reveal } from "./Reveal";

const checklist = [
  "Full-cycle product teams — strategy to launch",
  "In-house engineering & creative studio under one roof",
  "Agile sprints with transparent weekly demos",
  "Enterprise-grade security & code standards",
];

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden py-28 md:py-36">
      {/* watermark */}
      <span className="text-stroke-faint pointer-events-none absolute -top-6 right-0 select-none font-display text-[22vw] font-bold leading-none">
        01
      </span>

      <div className="mx-auto grid max-w-7xl items-center gap-16 px-6 lg:grid-cols-2 lg:gap-20 lg:px-8">
        {/* visual */}
        <Reveal className="relative">
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-neon/20 via-transparent to-grape/20 blur-2xl" />
            <div className="relative overflow-hidden rounded-[1.75rem] border border-white/10">
              <img
                src="/images/about-team.jpg"
                alt="SJ TCS engineering studio"
                className="h-[420px] w-full object-cover md:h-[520px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-void/80 via-transparent to-transparent" />
            </div>

            {/* floating badge */}
            <div className="glass absolute -bottom-8 left-6 flex items-center gap-4 rounded-2xl px-6 py-5 shadow-[0_20px_60px_rgba(0,0,0,0.5)] md:left-10">
              <span className="font-display text-4xl font-bold text-neon">
                <Counter to={8} suffix="+" />
              </span>
              <span className="max-w-[140px] text-xs font-medium uppercase tracking-[0.18em] text-white/60">
                Years of Engineering Excellence
              </span>
            </div>

            {/* orbit ring */}
            <div className="absolute -right-8 -top-8 hidden h-36 w-36 animate-spin-slow rounded-full border border-dashed border-neon/30 md:block">
              <span className="absolute left-1/2 top-0 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon shadow-[0_0_16px_rgba(0,229,255,0.8)]" />
            </div>
          </div>
        </Reveal>

        {/* copy */}
        <div className="relative">
          <Reveal>
            <Eyebrow>Who We Are</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-5 font-display text-4xl font-bold leading-[1.08] tracking-tight md:text-5xl">
              One Team.{" "}
              <Gradient>Every Digital Discipline.</Gradient>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 text-base leading-relaxed text-white/55 md:text-lg">
              SJ TCS is a full-spectrum technology consultancy. From the first
              line of code to the final color grade, we design, engineer and
              produce everything your brand needs to dominate the digital
              space — software, platforms and media, all under one roof.
            </p>
          </Reveal>
          <Reveal delay={0.24}>
            <p className="mt-4 text-base leading-relaxed text-white/55 md:text-lg">
              No hand-offs. No agency ping-pong. Just one obsessive team
              shipping world-class products at startup speed.
            </p>
          </Reveal>

          <div className="mt-9 flex flex-col gap-4">
            {checklist.map((item, i) => (
              <Reveal key={item} delay={0.3 + i * 0.07}>
                <div className="flex items-start gap-3.5">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-neon" />
                  <span className="text-sm leading-relaxed text-white/70 md:text-base">
                    {item}
                  </span>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.6}>
            <button
              onClick={() => scrollToTarget("#process")}
              className="group mt-10 inline-flex items-center gap-3 font-display text-sm font-bold uppercase tracking-widest text-neon"
            >
              Discover Our Process
              <span className="grid h-10 w-10 place-items-center rounded-full border border-neon/40 transition-all duration-300 group-hover:bg-neon group-hover:text-void group-hover:shadow-[0_0_24px_rgba(0,229,255,0.5)]">
                <ArrowRight className="h-4 w-4" />
              </span>
            </button>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
