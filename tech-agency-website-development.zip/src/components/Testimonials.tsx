import { Quote, Star } from "lucide-react";
import { Gradient, Reveal, SectionHeading } from "./Reveal";

const testimonials = [
  {
    quote:
      "SJ TCS rebuilt our entire SaaS platform in twelve weeks. Load times dropped 70%, and our conversion rate doubled. They operate at a level we've never seen from an external team.",
    name: "Aarav Mehta",
    role: "CEO, NexaFlow",
    initials: "AM",
  },
  {
    quote:
      "Their video team turned hours of raw footage into a brand film that directly won us three enterprise clients. Cinematic, precise, and delivered ahead of schedule.",
    name: "Sarah Collins",
    role: "CMO, Auric Media",
    initials: "SC",
  },
  {
    quote:
      "From app design to launch, communication was flawless — weekly demos, zero surprises. It genuinely felt like working with an elite in-house team.",
    name: "David Kim",
    role: "Founder, VaultPay",
    initials: "DK",
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative overflow-hidden py-28 md:py-36">
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[500px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon/[0.04] blur-[150px]" />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeading
          eyebrow="Client Voices"
          title={
            <>
              Loved by Founders. <Gradient>Trusted by Leaders.</Gradient>
            </>
          }
        />

        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.12} className="h-full">
              <div
                data-hover
                className="group relative flex h-full flex-col rounded-3xl border border-white/[0.07] bg-white/[0.02] p-8 transition-all duration-500 hover:-translate-y-1.5 hover:border-grape/40 hover:bg-white/[0.035]"
              >
                <Quote className="h-8 w-8 text-grape/50 transition-colors duration-500 group-hover:text-grape" />
                <div className="mt-5 flex gap-1">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star
                      key={s}
                      className="h-4 w-4 text-neon"
                      fill="currentColor"
                    />
                  ))}
                </div>
                <p className="mt-5 flex-1 text-sm leading-relaxed text-white/60 md:text-[15px]">
                  "{t.quote}"
                </p>
                <div className="mt-8 flex items-center gap-4 border-t border-white/[0.07] pt-6">
                  <span className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-neon to-grape font-display text-sm font-bold text-void">
                    {t.initials}
                  </span>
                  <div>
                    <p className="font-display text-sm font-bold text-white">
                      {t.name}
                    </p>
                    <p className="text-xs text-white/40">{t.role}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
