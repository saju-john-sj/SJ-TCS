import {
  ArrowUpRight,
  Bot,
  Braces,
  Clapperboard,
  Cloud,
  Globe,
  Music4,
  Palette,
  Smartphone,
  type LucideIcon,
} from "lucide-react";
import { scrollToTarget } from "../lib/scroll";
import { Gradient, Reveal, SectionHeading } from "./Reveal";

type Service = {
  icon: LucideIcon;
  title: string;
  desc: string;
  tags: string[];
};

const services: Service[] = [
  {
    icon: Globe,
    title: "Website Development",
    desc: "Blazing-fast, pixel-perfect websites and web apps — from immersive brand sites to complex enterprise portals.",
    tags: ["React", "Next.js", "E-Commerce", "CMS"],
  },
  {
    icon: Braces,
    title: "Software Development",
    desc: "Robust desktop and enterprise software engineered for scale, security and seamless system integration.",
    tags: ["Enterprise", "APIs", "Automation", "Desktop"],
  },
  {
    icon: Smartphone,
    title: "Mobile App Development",
    desc: "Native-quality iOS and Android applications with buttery performance and intuitive, conversion-focused UX.",
    tags: ["iOS", "Android", "Flutter", "React Native"],
  },
  {
    icon: Cloud,
    title: "SaaS Solutions",
    desc: "End-to-end SaaS products — multi-tenant architecture, billing, analytics dashboards and DevOps pipelines.",
    tags: ["Multi-tenant", "Stripe", "AWS", "Dashboards"],
  },
  {
    icon: Clapperboard,
    title: "Video Editing",
    desc: "Cinematic editing, motion graphics, VFX and color grading that make your story impossible to ignore.",
    tags: ["Premiere Pro", "After Effects", "DaVinci", "VFX"],
  },
  {
    icon: Music4,
    title: "Audio Editing",
    desc: "Studio-grade mixing, mastering, podcast production and sound design with pristine sonic clarity.",
    tags: ["Mixing", "Mastering", "Podcast", "Sound Design"],
  },
  {
    icon: Palette,
    title: "Image Editing & Design",
    desc: "High-end retouching, product visuals, thumbnails and complete brand identity systems that convert.",
    tags: ["Retouching", "Branding", "Thumbnails", "3D"],
  },
  {
    icon: Bot,
    title: "AI & Automation",
    desc: "Custom AI integrations, intelligent chatbots and workflow automation that multiply your team's output.",
    tags: ["Chatbots", "LLMs", "Workflows", "Data"],
  },
];

function ServiceCard({ service, index }: { service: Service; index: number }) {
  const Icon = service.icon;
  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
  };

  return (
    <Reveal delay={(index % 4) * 0.08} className="h-full">
      <div
        onMouseMove={onMove}
        data-hover
        className="spotlight-card group relative flex h-full flex-col overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.02] p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-neon/30 hover:bg-white/[0.04]"
      >
        <div className="mb-7 flex items-start justify-between">
          <div className="relative">
            <div className="absolute inset-0 rounded-xl bg-neon/30 opacity-0 blur-lg transition-opacity duration-500 group-hover:opacity-100" />
            <div className="relative grid h-13 w-13 place-items-center rounded-xl border border-white/10 bg-gradient-to-br from-white/[0.06] to-transparent p-3.5 transition-colors duration-500 group-hover:border-neon/40">
              <Icon className="h-6 w-6 text-neon" />
            </div>
          </div>
          <span className="font-display text-sm font-semibold text-white/15 transition-colors duration-500 group-hover:text-neon/50">
            /{String(index + 1).padStart(2, "0")}
          </span>
        </div>

        <h3 className="font-display text-xl font-bold text-white transition-colors duration-300 group-hover:text-neon">
          {service.title}
        </h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-white/50">
          {service.desc}
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          {service.tags.map((t) => (
            <span
              key={t}
              className="rounded-full border border-white/[0.08] px-3 py-1 text-[10px] font-medium uppercase tracking-wider text-white/40 transition-colors duration-300 group-hover:border-neon/25 group-hover:text-white/60"
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </Reveal>
  );
}

export default function Services() {
  return (
    <section id="services" className="relative overflow-hidden py-28 md:py-36">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-grape/[0.07] blur-[140px]" />
      <span className="text-stroke-faint pointer-events-none absolute -top-6 left-0 select-none font-display text-[22vw] font-bold leading-none">
        02
      </span>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeading
          eyebrow="What We Do"
          title={
            <>
              Every Capability. <Gradient>One Roof.</Gradient>
            </>
          }
          description="Eight battle-tested disciplines, one integrated team. Whether you need a product engineered, a platform scaled, or a story told — we deliver."
        />

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
          {services.map((s, i) => (
            <ServiceCard key={s.title} service={s} index={i} />
          ))}
        </div>

        {/* CTA strip */}
        <Reveal delay={0.15}>
          <div className="mt-14 flex flex-col items-center justify-between gap-8 overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-r from-neon/[0.06] via-white/[0.03] to-grape/[0.06] px-10 py-10 md:flex-row">
            <div>
              <h3 className="font-display text-2xl font-bold text-white md:text-3xl">
                Have a bold idea that doesn't fit a box?
              </h3>
              <p className="mt-2 text-sm text-white/50 md:text-base">
                Custom domains, hybrid projects, moonshot builds — we love the
                ones nobody else will touch.
              </p>
            </div>
            <button
              onClick={() => scrollToTarget("#contact")}
              className="group inline-flex shrink-0 items-center gap-3 rounded-full bg-gradient-to-r from-neon to-grape px-8 py-4 font-display text-sm font-bold uppercase tracking-widest text-void transition-all duration-300 hover:shadow-[0_0_44px_rgba(139,92,246,0.5)]"
            >
              Let's Talk
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
