import { motion } from "framer-motion";
import {
  CheckCircle2,
  Clock,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import { useState } from "react";
import { Eyebrow, Gradient, Reveal } from "./Reveal";
import {
  GithubIcon,
  InstagramIcon,
  LinkedinIcon,
  XIcon,
  YoutubeIcon,
} from "./SocialIcons";

const contactInfo = [
  {
    icon: Mail,
    label: "Email Us",
    value: "hello@sjtcs.io",
    href: "mailto:hello@sjtcs.io",
  },
  {
    icon: Phone,
    label: "Call Us",
    value: "+91 98765 43210",
    href: "tel:+919876543210",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "Remote-First · Serving Worldwide",
    href: undefined,
  },
];

const socials = [
  { icon: GithubIcon, label: "GitHub" },
  { icon: LinkedinIcon, label: "LinkedIn" },
  { icon: XIcon, label: "X (Twitter)" },
  { icon: InstagramIcon, label: "Instagram" },
  { icon: YoutubeIcon, label: "YouTube" },
];

const inputClass =
  "w-full rounded-xl border border-white/10 bg-void/60 px-5 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-all duration-300 focus:border-neon/60 focus:shadow-[0_0_0_3px_rgba(0,229,255,0.08)]";

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setSent(true);
    }, 900);
  };

  return (
    <section id="contact" className="relative overflow-hidden py-28 md:py-36">
      <div className="pointer-events-none absolute bottom-0 left-1/2 h-[420px] w-[900px] -translate-x-1/2 rounded-full bg-neon/[0.06] blur-[150px]" />
      <span className="text-stroke-faint pointer-events-none absolute -top-6 right-0 select-none font-display text-[22vw] font-bold leading-none">
        05
      </span>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid gap-16 lg:grid-cols-[1.05fr_1fr] lg:gap-20">
          {/* left */}
          <div>
            <Reveal>
              <Eyebrow>Get In Touch</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-5 font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl">
                Let's Build Something{" "}
                <Gradient>Extraordinary.</Gradient>
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-6 max-w-md text-base leading-relaxed text-white/55 md:text-lg">
                Tell us where you want to go. We'll map the fastest route —
                with a free 30-minute strategy call and a no-obligation
                proposal.
              </p>
            </Reveal>

            <div className="mt-10 flex flex-col gap-5">
              {contactInfo.map((c, i) => (
                <Reveal key={c.label} delay={0.2 + i * 0.08}>
                  <div className="flex items-center gap-5">
                    <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.03]">
                      <c.icon className="h-5 w-5 text-neon" />
                    </span>
                    <div>
                      <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-white/35">
                        {c.label}
                      </p>
                      {c.href ? (
                        <a
                          href={c.href}
                          className="font-display text-base font-semibold text-white/85 transition-colors hover:text-neon md:text-lg"
                        >
                          {c.value}
                        </a>
                      ) : (
                        <p className="font-display text-base font-semibold text-white/85 md:text-lg">
                          {c.value}
                        </p>
                      )}
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={0.45}>
              <div className="mt-12 flex items-center gap-4 rounded-2xl border border-neon/15 bg-neon/[0.04] px-6 py-4">
                <Clock className="h-5 w-5 shrink-0 text-neon" />
                <p className="text-sm text-white/60">
                  Average response time:{" "}
                  <span className="font-semibold text-neon">under 4 hours</span>{" "}
                  — even on weekends.
                </p>
              </div>
            </Reveal>

            <Reveal delay={0.55}>
              <div className="mt-10 flex gap-3">
                {socials.map((s) => (
                  <a
                    key={s.label}
                    href="#contact"
                    aria-label={s.label}
                    onClick={(e) => e.preventDefault()}
                    className="grid h-11 w-11 place-items-center rounded-full border border-white/10 text-white/50 transition-all duration-300 hover:border-neon/50 hover:bg-neon/10 hover:text-neon"
                  >
                    <s.icon className="h-4.5 w-4.5" />
                  </a>
                ))}
              </div>
            </Reveal>
          </div>

          {/* form */}
          <Reveal delay={0.2}>
            <div className="relative">
              <div className="absolute -inset-px rounded-[1.6rem] bg-gradient-to-br from-neon/40 via-white/5 to-grape/40" />
              <div className="relative rounded-[1.55rem] bg-abyss/95 p-8 md:p-10">
                {sent ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.92 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex min-h-[480px] flex-col items-center justify-center gap-5 text-center"
                  >
                    <span className="grid h-20 w-20 place-items-center rounded-full bg-neon/10">
                      <CheckCircle2 className="h-10 w-10 text-neon" />
                    </span>
                    <h3 className="font-display text-2xl font-bold text-white">
                      Message Transmitted
                    </h3>
                    <p className="max-w-xs text-sm leading-relaxed text-white/50">
                      Our team is decoding your brief right now. Expect a reply
                      within 4 working hours.
                    </p>
                    <button
                      onClick={() => setSent(false)}
                      className="mt-2 font-display text-xs font-bold uppercase tracking-widest text-neon underline-offset-4 hover:underline"
                    >
                      Send another message
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={onSubmit} className="flex flex-col gap-5">
                    <div className="grid gap-5 sm:grid-cols-2">
                      <div>
                        <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.25em] text-white/40">
                          Your Name
                        </label>
                        <input
                          required
                          placeholder="John Carter"
                          className={inputClass}
                        />
                      </div>
                      <div>
                        <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.25em] text-white/40">
                          Email
                        </label>
                        <input
                          required
                          type="email"
                          placeholder="john@company.com"
                          className={inputClass}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.25em] text-white/40">
                        What Do You Need?
                      </label>
                      <select className={inputClass} defaultValue="Website Development">
                        {[
                          "Website Development",
                          "Software Development",
                          "Mobile App",
                          "SaaS Platform",
                          "Video Editing",
                          "Audio Editing",
                          "Image Editing & Design",
                          "AI & Automation",
                          "Something Else",
                        ].map((o) => (
                          <option key={o} className="bg-abyss">
                            {o}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.25em] text-white/40">
                        Project Brief
                      </label>
                      <textarea
                        required
                        rows={5}
                        placeholder="Tell us about your vision, timeline and goals..."
                        className={`${inputClass} resize-none`}
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={sending}
                      className="group mt-2 inline-flex items-center justify-center gap-3 rounded-xl bg-gradient-to-r from-neon to-grape py-4 font-display text-sm font-bold uppercase tracking-widest text-void transition-all duration-300 hover:shadow-[0_0_44px_rgba(0,229,255,0.4)] disabled:opacity-60"
                    >
                      {sending ? "Transmitting..." : "Send Message"}
                      <Send className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </button>
                  </form>
                )}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
