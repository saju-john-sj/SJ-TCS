import { Sparkle } from "lucide-react";

const rowOne = [
  "Web Development",
  "SaaS Platforms",
  "Mobile Apps",
  "Video Editing",
  "Audio Production",
  "UI/UX Design",
  "Software Engineering",
  "Image Editing",
  "Cloud Solutions",
  "AI Automation",
];

const rowTwo = [
  "Innovation",
  "Precision",
  "Scalability",
  "Creativity",
  "Performance",
  "Security",
];

function MarqueeRow({
  items,
  outline = false,
  reverse = false,
  fast = false,
}: {
  items: string[];
  outline?: boolean;
  reverse?: boolean;
  fast?: boolean;
}) {
  const content = [...items, ...items];
  return (
    <div className="flex overflow-hidden">
      <div
        className={`flex w-max items-center gap-8 pr-8 md:gap-14 md:pr-14 ${
          fast ? "animate-marquee-fast" : "animate-marquee"
        }`}
        style={reverse ? { animationDirection: "reverse" } : undefined}
      >
        {content.map((item, i) => (
          <div key={i} className="flex items-center gap-8 md:gap-14">
            <span
              className={`whitespace-nowrap font-display text-4xl font-bold uppercase tracking-tight md:text-6xl ${
                outline ? "text-stroke" : "text-white/90"
              }`}
            >
              {item}
            </span>
            <Sparkle
              className={`h-6 w-6 shrink-0 md:h-8 md:w-8 ${
                outline ? "text-neon/40" : "text-neon"
              }`}
              fill="currentColor"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Marquee() {
  return (
    <section className="relative overflow-hidden border-y border-white/[0.06] bg-white/[0.015] py-10">
      <div className="flex flex-col gap-8">
        <MarqueeRow items={rowOne} />
        <MarqueeRow items={rowTwo} outline reverse fast />
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-void to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-void to-transparent" />
    </section>
  );
}
