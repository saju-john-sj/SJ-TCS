import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { scrollToTarget } from "../lib/scroll";
import { EASE } from "./Reveal";

export function Logo() {
  return (
    <button
      onClick={() => scrollToTarget(0)}
      className="group flex items-center gap-3"
      aria-label="SJ TCS — back to top"
    >
      <div className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl bg-gradient-to-br from-neon to-grape font-display text-base font-bold text-void shadow-[0_0_24px_rgba(0,229,255,0.35)] transition-shadow duration-300 group-hover:shadow-[0_0_36px_rgba(139,92,246,0.55)]">
        SJ
      </div>
      <div className="text-left leading-none">
        <span className="font-display text-lg font-bold tracking-wide text-white">
          SJ <span className="text-neon">TCS</span>
        </span>
        <span className="mt-1 block text-[8.5px] font-medium tracking-[0.3em] text-white/40">
          TECHNICAL CONSULTANCY
        </span>
      </div>
    </button>
  );
}

const links = [
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Process", href: "#process" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (href: string) => {
    setOpen(false);
    setTimeout(() => scrollToTarget(href), open ? 350 : 0);
  };

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.15, ease: EASE }}
        className={`fixed inset-x-0 top-0 z-[85] transition-all duration-500 ${
          scrolled
            ? "border-b border-white/[0.06] bg-void/70 backdrop-blur-xl"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-6 lg:px-8">
          <Logo />

          <nav className="hidden items-center gap-9 lg:flex">
            {links.map((l) => (
              <button
                key={l.href}
                onClick={() => go(l.href)}
                className="group relative text-[13px] font-medium tracking-wide text-white/60 transition-colors duration-300 hover:text-white"
              >
                {l.label}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-gradient-to-r from-neon to-grape transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </nav>

          <div className="hidden lg:block">
            <button
              onClick={() => go("#contact")}
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full border border-neon/40 px-6 py-2.5 text-[13px] font-semibold text-neon transition-all duration-300 hover:bg-neon hover:text-void hover:shadow-[0_0_30px_rgba(0,229,255,0.4)]"
            >
              Start a Project
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          <button
            onClick={() => setOpen(true)}
            className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/[0.03] text-white lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 z-[95] flex flex-col bg-void/95 backdrop-blur-2xl lg:hidden"
          >
            <div className="flex h-[76px] items-center justify-between px-6">
              <Logo />
              <button
                onClick={() => setOpen(false)}
                className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/[0.03] text-white"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex flex-1 flex-col items-start justify-center gap-2 px-8">
              {links.map((l, i) => (
                <motion.button
                  key={l.href}
                  initial={{ opacity: 0, x: -32 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 + i * 0.06, duration: 0.5, ease: EASE }}
                  onClick={() => go(l.href)}
                  className="group flex items-baseline gap-4 py-3"
                >
                  <span className="font-display text-xs text-neon/60">
                    0{i + 1}
                  </span>
                  <span className="font-display text-4xl font-bold text-white/80 transition-colors group-hover:text-neon">
                    {l.label}
                  </span>
                </motion.button>
              ))}
            </nav>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="px-8 pb-12"
            >
              <button
                onClick={() => go("#contact")}
                className="w-full rounded-full bg-gradient-to-r from-neon to-grape py-4 font-display text-sm font-bold uppercase tracking-widest text-void"
              >
                Start a Project
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
