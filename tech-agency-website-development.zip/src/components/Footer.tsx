import { ArrowUp } from "lucide-react";
import { scrollToTarget } from "../lib/scroll";
import { Logo } from "./Navbar";
import {
  GithubIcon,
  InstagramIcon,
  LinkedinIcon,
  XIcon,
  YoutubeIcon,
} from "./SocialIcons";

const serviceLinks = [
  "Website Development",
  "Software Development",
  "Mobile Apps",
  "SaaS Solutions",
  "Video & Audio Production",
  "Image Editing & Design",
];

const companyLinks = [
  { label: "About Us", href: "#about" },
  { label: "Our Process", href: "#process" },
  { label: "Selected Work", href: "#work" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

const socials = [
  { icon: GithubIcon, label: "GitHub" },
  { icon: LinkedinIcon, label: "LinkedIn" },
  { icon: XIcon, label: "X (Twitter)" },
  { icon: InstagramIcon, label: "Instagram" },
  { icon: YoutubeIcon, label: "YouTube" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/[0.07] bg-abyss/60">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* main */}
        <div className="grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-white/45">
              SJ Technical Consultancy Services — engineering websites,
              software, apps, SaaS platforms and cinematic media for
              ambitious brands worldwide.
            </p>
            <div className="mt-7 flex gap-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  onClick={(e) => e.preventDefault()}
                  className="grid h-10 w-10 place-items-center rounded-full border border-white/10 text-white/45 transition-all duration-300 hover:border-neon/50 hover:bg-neon/10 hover:text-neon"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-[0.3em] text-white/35">
              Services
            </h4>
            <ul className="mt-6 flex flex-col gap-3.5">
              {serviceLinks.map((s) => (
                <li key={s}>
                  <button
                    onClick={() => scrollToTarget("#services")}
                    className="text-sm text-white/55 transition-colors hover:text-neon"
                  >
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-[0.3em] text-white/35">
              Company
            </h4>
            <ul className="mt-6 flex flex-col gap-3.5">
              {companyLinks.map((l) => (
                <li key={l.label}>
                  <button
                    onClick={() => scrollToTarget(l.href)}
                    className="text-sm text-white/55 transition-colors hover:text-neon"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-[0.3em] text-white/35">
              Contact
            </h4>
            <ul className="mt-6 flex flex-col gap-3.5 text-sm text-white/55">
              <li>
                <a href="mailto:hello@sjtcs.io" className="transition-colors hover:text-neon">
                  hello@sjtcs.io
                </a>
              </li>
              <li>
                <a href="tel:+919876543210" className="transition-colors hover:text-neon">
                  +91 98765 43210
                </a>
              </li>
              <li>Remote-First · Worldwide</li>
            </ul>
            <button
              onClick={() => scrollToTarget(0)}
              data-hover
              aria-label="Back to top"
              className="mt-8 grid h-12 w-12 place-items-center rounded-full border border-neon/30 text-neon transition-all duration-300 hover:bg-neon hover:text-void hover:shadow-[0_0_30px_rgba(0,229,255,0.5)]"
            >
              <ArrowUp className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* bottom bar */}
        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] py-7 md:flex-row">
          <p className="text-xs text-white/35">
            © 2026 SJ Technical Consultancy Services. All rights reserved.
          </p>
          <p className="font-display text-[10px] font-medium uppercase tracking-[0.3em] text-white/30">
            Designed & Engineered by <span className="text-neon/70">SJ TCS</span>
          </p>
        </div>
      </div>

      {/* watermark */}
      <div className="pointer-events-none relative flex justify-center overflow-hidden">
        <span className="text-stroke-faint -mb-[4vw] select-none font-display text-[19vw] font-bold leading-none tracking-tight">
          SJ TCS
        </span>
      </div>
    </footer>
  );
}
