import { Code2, Compass, PenTool, Rocket, type LucideIcon } from "lucide-react";
import { Gradient, Reveal, SectionHeading } from "./Reveal";

type Step = {
  icon: LucideIcon;
  num: string;
  title: string;
  desc: string;
  points: string[];
};

const steps: Step[] = [
  {
    icon: Compass,
    num: "01",
    title: "Discover",
    desc: "Deep-dive workshops to map your goals, users and technical landscape before a single pixel moves.",
    points: ["Stakeholder interviews", "Technical audit", "Roadmap & scope"],
  },
  {
    icon: PenTool,
    num: "02",
    title: "Design",
    desc: "From wireframes to pixel-perfect interfaces and storyboards — with prototypes you can actually feel.",
    points: ["UX architecture", "UI systems", "Interactive prototypes"],
  },
  {
    icon: Code2,
    num: "03",
    title: "Build",
    desc: "Agile sprints with weekly demos. Clean, tested, documented code and frame-accurate edits.",
    points: ["Agile sprints", "QA & testing", "Weekly demos"],
  },
  {
    icon: Rocket,
    num: "04",
    title: "Deploy & Scale",
    desc: "Zero-downtime launches, monitoring and continuous optimisation long after go-live.",
    points: ["CI/CD pipelines", "Monitoring", "Growth support"],
  },
];

export default function Process() {
  return (
    <section id="process" className="relative overflow-hidden py-28 md:py-36">
      <div className="grid-lines pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_75%)]" />
      <div className="pointer-events-none absolute right-0 top-1/3 h-[420px] w-[600px] rounded-full bg-neon/[0.05] blur-[140px]" />
      <span className="text-stroke-faint pointer-events-none absolute -top-6 right-0 select-none font-display text-[22vw] font-bold leading-none">
        03
      </span>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeading
          eyebrow="How We Work"
          title={
            <>
              From Idea to Impact, <Gradient>in Four Moves.</Gradient>
            </>
          }
          description="A battle-tested delivery framework refined over hundreds of launches — transparent, fast, and ruthlessly quality-obsessed."
        />

        <div className="relative">
          {/* connector line */}
          <div className="absolute left-0 right-0 top-10 hidden h-px bg-gradient-to-r from-transparent via-neon/30 to-transparent lg:block" />

          <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-6">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <Reveal key={step.num} delay={i * 0.12}>
                  <div className="group relative" data-hover>
                    <div className="relative z-10 mb-7 grid h-20 w-20 place-items-center rounded-2xl border border-white/10 bg-void shadow-[0_0_0_8px_rgba(3,0,20,1)] transition-all duration-500 group-hover:border-neon/50 group-hover:shadow-[0_0_40px_rgba(0,229,255,0.25)]">
                      <Icon className="h-8 w-8 text-neon transition-transform duration-500 group-hover:scale-110" />
                    </div>
                    <span className="text-stroke pointer-events-none absolute -top-4 right-0 select-none font-display text-7xl font-bold">
                      {step.num}
                    </span>
                    <h3 className="font-display text-2xl font-bold text-white">
                      {step.title}
                    </h3>
                    <p className="mt-3 text-sm leading-relaxed text-white/50">
                      {step.desc}
                    </p>
                    <ul className="mt-5 flex flex-col gap-2">
                      {step.points.map((p) => (
                        <li
                          key={p}
                          className="flex items-center gap-2.5 text-xs font-medium uppercase tracking-wider text-white/40"
                        >
                          <span className="h-1 w-1 rounded-full bg-neon" />
                          {p}
                        </li>
                      ))}
                    </ul>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
