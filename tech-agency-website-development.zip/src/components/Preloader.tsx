import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { EASE } from "./Reveal";

const letters = ["S", "J", " ", "T", "C", "S"];

export default function Preloader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((p) => {
        const next = p + Math.floor(Math.random() * 5) + 2;
        if (next >= 100) {
          clearInterval(timer);
          return 100;
        }
        return next;
      });
    }, 32);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      const t = setTimeout(onComplete, 550);
      return () => clearTimeout(t);
    }
  }, [progress, onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-void"
      exit={{ y: "-100%" }}
      transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
    >
      {/* ambient glows */}
      <div className="absolute -left-40 top-1/4 h-96 w-96 rounded-full bg-neon/10 blur-[120px]" />
      <div className="absolute -right-40 bottom-1/4 h-96 w-96 rounded-full bg-grape/10 blur-[120px]" />

      <div className="relative flex flex-col items-center gap-8">
        <motion.div
          initial={{ scale: 0.6, opacity: 0, rotate: -8 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
          className="grid h-20 w-20 place-items-center rounded-2xl bg-gradient-to-br from-neon to-grape font-display text-3xl font-bold text-void shadow-[0_0_60px_rgba(0,229,255,0.4)]"
        >
          SJ
        </motion.div>

        <div className="flex overflow-hidden">
          {letters.map((l, i) => (
            <motion.span
              key={i}
              initial={{ y: "110%" }}
              animate={{ y: 0 }}
              transition={{ delay: 0.25 + i * 0.06, duration: 0.7, ease: EASE }}
              className="font-display text-4xl font-bold tracking-[0.15em] text-white md:text-5xl"
            >
              {l === " " ? "\u00A0" : l}
            </motion.span>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-[10px] font-medium uppercase tracking-[0.5em] text-white/40"
        >
          Technical Consultancy Services
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 flex w-64 flex-col items-center gap-3"
        >
          <div className="h-px w-full overflow-hidden bg-white/10">
            <motion.div
              className="h-full bg-gradient-to-r from-neon to-grape"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex w-full items-center justify-between font-display text-xs tracking-widest text-white/40">
            <span>INITIALIZING</span>
            <span className="text-neon">{String(progress).padStart(3, "0")}%</span>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-8 left-8 hidden text-[10px] uppercase tracking-[0.3em] text-white/25 md:block">
        SJ TCS © 2026
      </div>
      <div className="absolute bottom-8 right-8 hidden text-[10px] uppercase tracking-[0.3em] text-white/25 md:block">
        Engineering Digital Excellence
      </div>
    </motion.div>
  );
}
