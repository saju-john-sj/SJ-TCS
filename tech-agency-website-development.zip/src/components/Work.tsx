import { ArrowUpRight } from "lucide-react";
import { scrollToTarget } from "../lib/scroll";
import { Gradient, Reveal, SectionHeading } from "./Reveal";

type Project = {
  title: string;
  category: string;
  result: string;
  image: string;
  tags: string[];
  span: string;
};

const projects: Project[] = [
  {
    title: "NexaFlow Analytics",
    category: "SaaS Platform · Web App",
    result:
      "Real-time analytics suite processing 40M+ events per day for a Fortune-500 retailer.",
    image: "/images/work-saas.jpg",
    tags: ["SaaS", "React", "Data Viz"],
    span: "lg:col-span-7",
  },
  {
    title: "VaultPay",
    category: "Mobile App · Fintech",
    result:
      "A neobank experience rated 4.9★ with 200K downloads in its first quarter.",
    image: "/images/work-app.jpg",
    tags: ["iOS", "Android", "Fintech"],
    span: "lg:col-span-5",
  },
  {
    title: "Aurora Brand Film",
    category: "Video Production · Color Grade",
    result:
      "A cinematic brand film that closed three enterprise contracts within a month.",
    image: "/images/work-video.jpg",
    tags: ["Editing", "VFX", "Grading"],
    span: "lg:col-span-5",
  },
  {
    title: "LUXE Commerce",
    category: "E-Commerce · Web Experience",
    result:
      "A headless storefront that lifted conversion rates by 142% post-launch.",
    image: "/images/work-ecom.jpg",
    tags: ["E-Commerce", "Headless", "CRO"],
    span: "lg:col-span-7",
  },
];

function ProjectCard({ project, index }: { project: Project; index: number }) {
  return (
    <Reveal delay={(index % 2) * 0.1} className={project.span}>
      <div
        data-hover
        className="group relative h-[340px] overflow-hidden rounded-3xl border border-white/[0.08] md:h-[400px]"
      >
        <img
          src={project.image}
          alt={project.title}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-[1.06]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/35 to-transparent opacity-90 transition-opacity duration-500 group-hover:opacity-100" />

        {/* top row */}
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-6 md:p-8">
          <div className="flex flex-wrap gap-2">
            {project.tags.map((t) => (
              <span
                key={t}
                className="rounded-full border border-white/15 bg-void/40 px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-white/70 backdrop-blur-md"
              >
                {t}
              </span>
            ))}
          </div>
          <span className="grid h-12 w-12 shrink-0 translate-y-2 place-items-center rounded-full bg-neon text-void opacity-0 shadow-[0_0_30px_rgba(0,229,255,0.5)] transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
            <ArrowUpRight className="h-5 w-5" />
          </span>
        </div>

        {/* bottom content */}
        <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
          <span className="text-[10px] font-semibold uppercase tracking-[0.28em] text-neon">
            {project.category}
          </span>
          <h3 className="mt-2 font-display text-2xl font-bold text-white md:text-3xl">
            {project.title}
          </h3>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-white/55 transition-colors duration-500 group-hover:text-white/75">
            {project.result}
          </p>
        </div>
      </div>
    </Reveal>
  );
}

export default function Work() {
  return (
    <section id="work" className="relative overflow-hidden py-28 md:py-36">
      <div className="pointer-events-none absolute left-0 top-1/4 h-[420px] w-[600px] rounded-full bg-grape/[0.06] blur-[140px]" />
      <span className="text-stroke-faint pointer-events-none absolute -top-6 left-0 select-none font-display text-[22vw] font-bold leading-none">
        04
      </span>

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeading
          eyebrow="Selected Work"
          title={
            <>
              Proof, <Gradient>Not Promises.</Gradient>
            </>
          }
          description="A snapshot of the products, platforms and productions we've shipped for clients across 15+ countries."
        />

        <div className="grid gap-6 lg:grid-cols-12">
          {projects.map((p, i) => (
            <ProjectCard key={p.title} project={p} index={i} />
          ))}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-12 flex justify-center">
            <button
              onClick={() => scrollToTarget("#contact")}
              className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-8 py-4 font-display text-sm font-bold uppercase tracking-widest text-white/70 transition-all duration-300 hover:border-neon/50 hover:text-neon"
            >
              Your Project Could Be Next
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
