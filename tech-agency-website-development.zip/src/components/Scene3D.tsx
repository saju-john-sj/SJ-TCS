import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

const vertexShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uMouse;
  uniform float uPixelRatio;
  varying float vElevation;
  varying float vDepth;

  void main() {
    vec3 pos = position;

    float wave = 0.0;
    wave += sin(pos.x * 0.55 + uTime * 0.7) * 0.34;
    wave += sin(pos.y * 0.42 + uTime * 0.5) * 0.28;
    wave += sin((pos.x * 0.3 + pos.y * 0.5) + uTime * 0.35) * 0.24;

    // Interactive ripple that follows the cursor
    vec2 mouseWorld = vec2(uMouse.x * 16.0, uMouse.y * 12.0);
    float d = distance(pos.xy, mouseWorld);
    wave += 0.55 * sin(d * 1.6 - uTime * 2.4) * smoothstep(7.0, 0.0, d);

    pos.z += wave;
    vElevation = wave;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    vDepth = -mvPosition.z;
    gl_PointSize = uPixelRatio * (30.0 / vDepth);
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = /* glsl */ `
  varying float vElevation;
  varying float vDepth;

  void main() {
    float dist = distance(gl_PointCoord, vec2(0.5));
    if (dist > 0.5) discard;
    float strength = smoothstep(0.5, 0.08, dist);

    vec3 cyan = vec3(0.0, 0.86, 1.0);
    vec3 violet = vec3(0.56, 0.3, 1.0);
    float mixVal = smoothstep(-0.7, 0.95, vElevation);
    vec3 color = mix(cyan, violet, mixVal);

    float fade = smoothstep(28.0, 6.0, vDepth);
    float alpha = strength * fade * (0.22 + 0.78 * mixVal);
    gl_FragColor = vec4(color, alpha * 0.8);
  }
`;

function WaveField() {
  const mouse = useRef(new THREE.Vector2(0, 0));

  const { geometry, material } = useMemo(() => {
    const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
    const cols = isMobile ? 120 : 200;
    const rows = isMobile ? 90 : 150;
    const width = 52;
    const depth = 36;
    const positions = new Float32Array(cols * rows * 3);
    let i = 0;
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        positions[i * 3] = (x / (cols - 1) - 0.5) * width;
        positions[i * 3 + 1] = (y / (rows - 1) - 0.5) * depth;
        positions[i * 3 + 2] = 0;
        i++;
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uMouse: { value: new THREE.Vector2(0, 0) },
        uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
      },
      vertexShader,
      fragmentShader,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    return { geometry: geo, material: mat };
  }, []);

  useFrame((state) => {
    material.uniforms.uTime.value = state.clock.elapsedTime;
    mouse.current.x += (state.pointer.x - mouse.current.x) * 0.04;
    mouse.current.y += (state.pointer.y - mouse.current.y) * 0.04;
    material.uniforms.uMouse.value.copy(mouse.current);
  });

  return (
    <points
      geometry={geometry}
      material={material}
      rotation={[-Math.PI / 2, 0, 0]}
      position={[0, -1.6, -2]}
    />
  );
}

function StarField() {
  const ref = useRef<THREE.Points>(null);
  const geometry = useMemo(() => {
    const count = 800;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 70;
      positions[i * 3 + 1] = Math.random() * 26 - 5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 70;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return g;
  }, []);

  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 0.008;
  });

  return (
    <points ref={ref} geometry={geometry}>
      <pointsMaterial
        size={0.055}
        color="#7dd3fc"
        transparent
        opacity={0.55}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function CameraRig() {
  useFrame((state) => {
    state.camera.position.x +=
      (state.pointer.x * 1.2 - state.camera.position.x) * 0.035;
    state.camera.position.y +=
      (1.9 + state.pointer.y * 0.5 - state.camera.position.y) * 0.035;
    state.camera.lookAt(0, 0.4, 0);
  });
  return null;
}

export default function Scene3D() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 1.9, 7.4], fov: 55 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      >
        <CameraRig />
        <WaveField />
        <StarField />
      </Canvas>
    </div>
  );
}
