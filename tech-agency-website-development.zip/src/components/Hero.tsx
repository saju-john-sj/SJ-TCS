import { motion } from "framer-motion";
import { ArrowUpRight, ChevronDown, Play } from "lucide-react";
import { scrollToTarget } from "../lib/scroll";
import Scene3D from "./Scene3D";
import { Counter, EASE } from "./Reveal";

const line = {
  hidden: { y: "115%" },
  show: (i: number) => ({
    y: 0,
    transition: { delay: 0.55 + i * 0.13, duration: 1, ease: EASE },
  }),
};

const stats = [
  { value: 250, suffix: "+", label: "Projects Delivered" },
  { value: 120, suffix: "+", label: "Happy Clients" },
  { value: 15, suffix: "+", label: "Countries Served" },
  { value: 99, suffix: "%", label: "Client Satisfaction" },
];

export default function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col overflow-hidden">
      <Scene3D />

      {/* overlays */}
      <div className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(3,0,20,0.55)_75%,#030014_100%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 z-[1] h-40 bg-gradient-to-b from-void to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] h-56 bg-gradient-to-t from-void via-void/60 to-transparent" />

      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col items-center justify-center px-6 pt-40 pb-16 text-center lg:px-8">
        {/* badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.7, ease: EASE }}
          className="mb-8 inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 backdrop-blur-md"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-neon opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-neon" />
          </span>
          <span className="text-[11px] font-semibold uppercase tracking-[0.25em] text-white/70">
            Next-Gen Technology Partner
          </span>
        </motion.div>

        {/* headline */}
        <h1 className="font-display font-bold leading-[0.95] tracking-tight">
          <span className="block overflow-hidden">
            <motion.span
              custom={0}
              variants={line}
              initial="hidden"
              animate="show"
              className="block text-[13vw] text-white sm:text-7xl md:text-8xl lg:text-[7.5rem]"
            >
              WE BUILD
            </motion.span>
          </span>
          <span className="block overflow-hidden">
            <motion.span
              custom={1}
              variants={line}
              initial="hidden"
              animate="show"
              className="block bg-gradient-to-r from-neon via-ice to-grape bg-clip-text text-[13vw] text-transparent drop-shadow-[0_0_40px_rgba(0,229,255,0.25)] sm:text-7xl md:text-8xl lg:text-[7.5rem]"
            >
              BEYOND
            </motion.span>
          </span>
          <span className="block overflow-hidden">
            <motion.span
              custom={2}
              variants={line}
              initial="hidden"
              animate="show"
              className="text-stroke block text-[13vw] sm:text-7xl md:text-8xl lg:text-[7.5rem]"
            >
              LIMITS
            </motion.span>
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.15, duration: 0.9, ease: EASE }}
          className="mt-8 max-w-2xl text-base leading-relaxed text-white/55 md:text-lg"
        >
          SJ Technical Consultancy Services crafts websites, software, mobile
          apps and SaaS platforms — plus cinematic video, audio and image
          production.{" "}
          <span className="text-white/85">One partner. Endless capability.</span>
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.9, ease: EASE }}
          className="mt-10 flex flex-col items-center gap-4 sm:flex-row"
        >
          <button
            onClick={() => scrollToTarget("#contact")}
            className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-gradient-to-r from-neon to-grape px-8 py-4 font-display text-sm font-bold uppercase tracking-widest text-void transition-all duration-300 hover:shadow-[0_0_50px_rgba(0,229,255,0.45)]"
          >
            <span className="absolute inset-0 -translate-x-full bg-white/25 transition-transform duration-500 group-hover:translate-x-0" />
            <span className="relative">Start a Project</span>
            <ArrowUpRight className="relative h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
          <button
            onClick={() => scrollToTarget("#work")}
            className="group inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.03] px-8 py-4 font-display text-sm font-bold uppercase tracking-widest text-white/80 backdrop-blur-md transition-all duration-300 hover:border-neon/50 hover:text-neon"
          >
            <Play className="h-4 w-4 fill-current" />
            Explore Our Work
          </button>
        </motion.div>
      </div>

      {/* stats bar */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.55, duration: 0.9, ease: EASE }}
        className="relative z-10 mx-auto w-full max-w-7xl px-6 pb-10 lg:px-8"
      >
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.04] backdrop-blur-xl md:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="flex flex-col items-center gap-1.5 bg-void/60 px-4 py-6"
            >
              <span className="font-display text-3xl font-bold text-white md:text-4xl">
                <Counter to={s.value} suffix={s.suffix} className="bg-gradient-to-r from-neon to-grape bg-clip-text text-transparent" />
              </span>
              <span className="text-[10px] font-medium uppercase tracking-[0.22em] text-white/45">
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* scroll hint */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        onClick={() => scrollToTarget("#about")}
        className="absolute bottom-40 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/35 transition-colors hover:text-neon xl:flex"
        aria-label="Scroll down"
      >
        <span className="text-[9px] font-medium uppercase tracking-[0.4em]">
          Scroll
        </span>
        <motion.span
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
        >
          <ChevronDown className="h-4 w-4" />
        </motion.span>
      </motion.button>
    </section>
  );
}
